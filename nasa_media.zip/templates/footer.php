<div id="footer">
	<p id="copyright">&copy; 20XX ○○○○ All Rights Reserved.</p>
</div><!-- /#footer -->


</div><!-- /#page -->


<div class="fixmenu">
	<div class="fixmenu_inner">
		<div class="box_menu">
			<ul>
				<li><a href="#">Giới thiệu</a></li>
				<li class="sub-menu">
					<a href="javascript:void(0);" class="accordion sp-only">Khóa học</a>
					<ul>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
						<li><a href="#">Lãnh đạo và quản lý</a></li>
					</ul>
				</li>
				<li><a href="#">Giảng viên</a></li>
				<li><a href="#">Hợp tác</a></li>
			</ul>
		</div>
		<div class="box-hotline">
			<p>Hotline: 0986121019</p>
			<p>Email: cskh.nasamedia@gmail.com</p>
		</div>
	</div>
</div><!-- /.fixmenu -->