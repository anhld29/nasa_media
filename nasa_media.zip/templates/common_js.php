<script src="<?php echo location_file;?>js/jquery-<?php echo (!$ie8) ? '2.1.4' : '1.7.2' ?>.min.js"></script>
<script src="<?php echo location_file;?>js/config.js"></script>
<script src="<?php echo location_file;?>js/common.js"></script>
<!-- <script src="<?php echo location_file;?>js/jquery.mmenu.js"></script> -->
