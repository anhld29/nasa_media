http_path = "/"
css_dir = "../css"
sass_dir = ""
images_dir = "../images"
javascripts_dir = "../js"
output_style = :expanded
relative_assets = true
line_comments = false

cache_dir = "../../.sass-cache" #キャッシュファイルの場所
# cache = false #キャッシュファイル作成の無効