<link href="<?php echo location_file; ?>css/default.css" rel="stylesheet" type="text/css" media="all">
<link href="<?php echo location_file; ?>css/print.css" rel="stylesheet" type="text/css" media="print">
<link rel="stylesheet" type="text/css" href="font/font-awesome/css/font-awesome.min.css" />     
<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
<link href="<?php echo location_file; ?>css/common.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo location_file; ?>css/bootstrap/4.1.3/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo location_file; ?>css/slick/slick-theme.css">
<link rel="stylesheet" href="<?php echo location_file; ?>css/home.css">