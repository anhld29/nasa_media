<?php
	
	//関数の定義やその他設定
	include dirname(__FILE__).'/setting.php';

	//定数の定義
	include dirname(__FILE__).'/config.php';

	//metaタグに関する設定
	include dirname(__FILE__).'/meta.php';

	//headの読み込み
	include dirname(__FILE__).'/../templates/head.php';


?>