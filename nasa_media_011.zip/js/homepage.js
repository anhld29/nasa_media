
/* Settings 
------------------------------------------------------------------------*/




/* Functions
------------------------------------------------------------------------*/




/* readyEvent 
------------------------------------------------------------------------*/

$(function(){



/* load & resize & scroll & firstLoad
------------------------------------------------------------------------*/
	
	$w.on({
		//load	
		'load' : function(){

		},
		//scroll	
		'scroll' : function(){

		}
	}).superResize({
		//resize
		resizeAfter : function(){

		}
	}).firstLoad({
		//firstLoad
		pc_tab : function(){

		},
		sp : function(){

		}
	});



});