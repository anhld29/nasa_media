<script src="<?php echo location_file;?>js/jquery-<?php echo (!$ie8) ? '2.1.4' : '1.7.2' ?>.min.js"></script>
<script src="<?php echo location_file;?>js/config.js"></script>
<script src="<?php echo location_file;?>js/common.js"></script>
<script src="<?php echo location_file;?>js/bootstrap/4.1.3/bootstrap.min.js"></script>
<script src="<?php echo location_file;?>js/slick.min.js"></script>
