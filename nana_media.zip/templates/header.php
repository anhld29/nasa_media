 
<div id="page">
<div id="header">
	<div class="con-header">
		<div class="wrap">
			<div class="box-menu-sp view_tab-sp">
				<a href="javascript:void(0);" class="menuopen over"><span class="fa fa-bars"></span></a>
			</div>
			<div class="box-logo"><a href="#" class="over"><img src="<?php echo location_file;?>images/logo.png" alt="Nasa Media"></a></div>
			<div class="box-menu-search view_pc">
				<ul class="list-main-menu">
					<li><a href="#" class="over">Giới thiệu</a></li>
					<li><a href="#" class="over">Khóa học</a></li>
					<li><a href="#" class="over">Giáo viên</a></li>
					<li><a href="#" class="over">Hợp tác</a></li>
				</ul>
				<div class="box-search">
					<input type="text" placeholder="Tìm khóa học, giảng viên.....">
					<button><i class="fa fa-search"></i></button>
				</div>
				<div class="box-cart">
					<a href="#">
					<span class="cart-icon">
						<span class="number-cart"><em>2</em></span>
						<i class="lnr lnr-cart"></i>
					</span>
					</a>
				</div>
			</div>
			<div class="box-search-sp menuSearch view_tab-sp">
				<i class="fa fa-search"></i>
			</div>
		</div>
	</div>
</div><!-- /#header -->


